## Mule Notification Billing API
 
### API Overview
This API is developed to send notifications to customers for bills generated in a specific cut.
 
##### Copyright
fredybeltrans@gmail.com.